# lepmlutils

This is a project containing utility functions to make machine learning easier. It is intended for my own private use. It's only a pip package to make it easier to access. 